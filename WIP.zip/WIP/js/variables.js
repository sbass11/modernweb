let x,y,z;

x=10;
y='10';
z=30;

console.log(`x is ${typeof x}`);
console.log(`x is ${typeof y}`);
console.log(`x is ${typeof z}`);

var newX = x++;

console.log("newX is " + newX);
console.log(x);
console.log("Does X equate to Y?  " + (x == y));

let timeInMs = Date.now();

console.log("timeInMs is " + timeInMs);

