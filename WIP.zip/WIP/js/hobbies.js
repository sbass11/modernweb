const hobbiesArray = [
    { name: 'knitting', lengthInYearsAtHobby: 1 },
    { name: 'reading', lengthInYearsAtHobby: 48},
    { name: 'sewing', lengthInYearsAtHobby: 43}
];

function printHobbyInfo(hobby) {
    console.log(` ${hobby.name} enjoyed for ${hobby.lengthInYearsAtHobby} `)
    
}
for (let x = 0; x < hobbiesArray.length; x++) {
    printHobbyInfo(hobbiesArray[x]);
}
