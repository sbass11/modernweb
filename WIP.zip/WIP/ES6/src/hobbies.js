const hobbiesArray = [
    { name: 'volleyball', lengthInYearsAtHobby: 25 },
    { name: 'cooking', lengthInYearsAtHobby: 15 },
    { name: 'swimming', lengthInYearsAtHobby: 11 }
];


function printHobbyInfo(hobby) {
    console.log(` ${hobby.name} has been an interest for ${hobby.lengthInYearsAtHobby} years`)
}

for (let hobby of hobbiesArray) {
    printHobbyInfo(hobby);
}
function returnHobbiesHTML() {
    let hobbyInfo = `
        <ul>
    `;
    hobbiesArray.forEach(hobby => {
        hobbyInfo+= `<li>${hobby.name} ${hobby.lengthInYearsAtHobby}</li>`;
        });
        hobbyInfo+=`</ul>`;
    return hobbyInfo;
}
